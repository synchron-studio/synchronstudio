Synchronstudio scene export
1. Unzip this archive into the root of the synchronstudio repo
   (it contains scenes/newscene.mp4, scenes/newscene/ and previews/newscene.mp4).
2. Add the object from scene.json to the list in scenes.json (comma between scenes).
3. Add the new characters to AVATAR_CHARS in client.js (optional, for profile pictures).
4. Run:  node tools/sync-scene-index.cjs
   The game only reads scenes-index.json + scenedata/ — without this step the scene does NOT show up.
5. Raise APP_VERSION (client.js + index.html), add patch notes, commit & push.
Scene id: newscene
Title: New Scene (1 Rolle)
Lines: 2